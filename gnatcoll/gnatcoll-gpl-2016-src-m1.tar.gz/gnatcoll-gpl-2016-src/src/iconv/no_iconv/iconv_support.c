/*
 * Iconv binding support
 * Copyright (C) 2015-2016, AdaCore
 */

/* The following is a stub to make it possible to build GNATCOLL.Iconv without
 * the actual Libiconv.  */

void
gnatcoll_iconv_set_locale (void)
{
  return;
}
